package com.account.api.service;

import com.account.api.entity.Account;
import com.account.api.repository.AccountRepository;
import com.account.api.service.impl.AccountServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class AccountServiceTest {

    @Mock
    private AccountRepository accountRepository;

    @InjectMocks
    private AccountServiceImpl accountService;

    private Account A1 = new Account("Paddy","Welbourn", "1");
    private Account A2 = new Account("Wren", "Flori", "2");
    private Account A3 = new Account("Ambrosio","Smewing", "3");

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        A1.setId(1L);
        A2.setId(2L);
        A3.setId(3L);
    }

    @Test
    public void testGetAllMembers() {
        //given
        given(accountRepository.findAll()).willReturn(Arrays.asList(A1, A2, A3));

        //calling method under the test
        List<Account> result = accountService.getAllAccounts();

        //assert respond has 3 objects
        assertThat(result).hasSize(3);

        //assert
        assertAccountFields(result.get(0));

        //verify that repository was called
        verify(accountRepository, times(1)).findAll();
    }

    @Test
    public void testGetAccountById() {
        //given
        given(accountRepository.findById(1L)).willReturn(Optional.of(A1));

        //calling method under the test
        Optional<Account> result = accountService.getAccountById(1L);

        //assert
        assertThat(result.isPresent()).isTrue();

        //assert
        assertAccountFields(result.orElseGet(null));

        //verify that repository was called
        verify(accountRepository, times(1)).findById(1L);
    }

    @Test
    public void testInsertAccount() {
        //given
        given(accountRepository.save(A1)).willReturn(A1);

        //calling method under the test
        Account result = accountService.saveAccount(A1);

        //assert
        assertAccountFields(result);

        //verify that repository was called
        verify(accountRepository, times(1)).save(A1);
    }

    @Test
    public void testRemoveAccount() {
        accountService.removeAccount(1L);

        //verify that repository was called
        verify(accountRepository, times(1)).deleteById(1L);
    }

    //verify that Account 'a1' object have same fields
    private void assertAccountFields(Account account) {
        assertThat(account.getId()).isInstanceOf(Long.class);
        assertThat(account.getId()).isEqualTo(1);
        assertThat(account.getFirstname()).isEqualTo("Paddy");
        assertThat(account.getSecondname()).isEqualTo("Welbourn");
        assertThat(account.getAccountnumber()).isEqualTo("1");
    }
}