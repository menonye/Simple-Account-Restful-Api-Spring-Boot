package com.account.api.controller;

import com.account.api.SpringRestApiTestApplication;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = SpringRestApiTestApplication.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountControllerTest {

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext wac;

    @Before
    public void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
    }


    @Test
    public void shouldFetchAllAccounts() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get(AccountController.URI)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
               // .andExpect(jsonPath("$", hasSize(2)))
                .andReturn();
    }


    @Test
    public void shouldFindAccountById() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get(AccountController.URI + "2")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.id").value(2))
                .andExpect(jsonPath("$.firstname").exists())
                .andExpect(jsonPath("$.firstname").value("Mary"))
                .andExpect(jsonPath("$.secondname").value("Brown"))
                .andExpect(jsonPath("$.accountnumber").value("2"))
                //.andExpect(jsonPath("$.*", hasSize(4)))
                .andReturn();
    }

    /*
    @Test
    public void shouldSaveAccount() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.post(AccountController.URI)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"firstname\": \"Philip\",\"secondname\": \"George\",\"accountnumber\": \"4\"}")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.firstname").exists())
                .andExpect(jsonPath("$.firstname").value("Philip"))
                .andExpect(jsonPath("$.secondname").value("George"))
                .andExpect(jsonPath("$.accountnumber").value("4"))
                .andExpect(jsonPath("$.*", hasSize(4)))
                .andReturn();

    }
*/

/*
    @Test
    public void shouldVerifyInvalidSaveAccount() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.post(AccountController.URI)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"firstname\": \"\",\"secondname\": \"George\",\"accountnumber\": \"44\"}")
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Bad request, a malformed or illegal request."))
                .andReturn();

    }

*/



    @Test
    public void shouldGetEndpoint() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get(AccountController.URI)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andReturn();
    }


}