package com.account.api.controller;

import com.account.api.entity.Account;
import com.account.api.exception.CustomException;
import com.account.api.exception.CustomResponse;
import com.account.api.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    static String URI = "/api/accounts/";

    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Account> fetchAllAccounts() {
        return accountService.getAllAccounts();
    }

    @GetMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Optional<Account> findAccountById(@PathVariable("id") Long id) throws CustomException {
        return Optional.of(accountService.getAccountById(id)
                .orElseThrow(() -> new CustomException("Account with ID: '" + id + "' not found.")));
    }

    @PostMapping(
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public Account saveAccount(@RequestBody @Validated Account account) {
        return accountService.saveAccount(account);
    }

    @PutMapping(produces = MediaType.APPLICATION_JSON_VALUE,consumes = MediaType.APPLICATION_JSON_VALUE)
    /*
    public Account updateMember(@RequestBody @Validated Account account) throws CustomException {
        if (accountService.getAccountById(account.getId()).isPresent()) {
            return accountService.saveAccount(account);
        } else {
            throw new CustomException("Account with ID: '" + account.getId() + "' not found.");
        }
    }
*/
    @DeleteMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CustomResponse> removeAccount(@PathVariable("id") long id) {
        if (accountService.getAccountById(id).isPresent()) {
            this.accountService.removeAccount(id);
            return new ResponseEntity<>(
                    new CustomResponse(HttpStatus.OK.value(),
                            "Account with ID: '" + id + "' deleted."), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(
                    new CustomResponse(HttpStatus.NOT_FOUND.value(),
                            "Account with ID: '" + id + "' not found."), HttpStatus.NOT_FOUND);
        }
    }
}
