package com.account.api.entity;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank
    @Column(unique = true, name = "firstname")
    private String firstname;

    @NotBlank
    @Column(unique = true, name = "secondname")
    private String secondname;

    @NotBlank
    @Column(unique = true, name = "accountnumber")
    private String accountnumber;

    public Account() {
    }

    public Account(String firstname, String secondname, String accountnumber) {
        this.firstname = firstname;
        this.secondname = secondname;
        this.accountnumber = accountnumber;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSecondname() {
        return secondname;
    }

    public void setSecondname(String secondname) {
        this.secondname = secondname;
    }

    public String getAccountnumber() {
        return accountnumber;
    }

    public void setAccountnumber(String accountnumber) {
        this.accountnumber = accountnumber;
    }

}
