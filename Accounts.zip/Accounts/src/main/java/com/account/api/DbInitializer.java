package com.account.api;

import com.account.api.entity.Account;
import com.account.api.repository.AccountRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DbInitializer implements CommandLineRunner {

    private AccountRepository accountRepository;

    public DbInitializer(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public void run(String... args) {

        /*
        INITIALIZE THE DATABASE AND POPULATE IT WITH SOME FAKE AUTHORS AND BOOKS
         */
         //   Account acc1 = new Account("John", "Wee", "1");
          //  Account acc2 = new Account("Mary", "Brown", "2");


        //this.accountRepository.save(acc1);
       // this.accountRepository.save(acc2);


    }
}
